<?php 
sendMessage($chatId, "checking card...", $message_id);

?>